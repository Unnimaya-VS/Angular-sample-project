import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './components/home/home.component';
import { AboutComponent } from './components/about/about.component';
import { ServiceComponent } from './components/service/service.component';
import { ContactComponent } from './components/contact/contact.component';
import { HeaderComponent } from './components/header/header.component';


const routes: Routes = [
  {
    path:'', redirectTo:'/home', pathMatch:'full' 
  },
  {
    path:'home', component:HomeComponent
  },
  {
    path:'about', component:AboutComponent
  },
  {
    path:'service',component:ServiceComponent
  },
  {
    path:'contact', component:ContactComponent
  },
  {
    path:'header', component:HeaderComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
